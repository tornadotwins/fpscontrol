﻿//#define DEBUG
using UnityEngine;
using UnityEditor;
using System.Collections;
using System.IO;
using System.Collections.Generic;
using FPSControl;

namespace FPSControlEditor
{
    public class FPSControlEditorModule
    {
        public static Rect MODULE_SIZE { get { return new Rect(246, 50, 660, 578); } }
        public static GUILayoutOption[] NONE { get { return new GUILayoutOption[0] { }; } }

        protected EditorWindow _editor;

        protected FPSControlModuleType _type = FPSControlModuleType.NONE;
        public virtual FPSControlModuleType type { get { return _type; } }

        public FPSControlEditorModule(EditorWindow editorWindow)
        {
            _editor = editorWindow;
        }

        public virtual void Init() { }
        public virtual void Deinit() { }
        public virtual void OnGUI() { }
        public virtual void Update() { }
        public virtual void OnFocus(bool rebuild) { }
        public virtual void OnLostFocus(bool rebuild) { }

        public void Repaint()
        {
            _editor.Repaint();
        }

        internal T Load<T>(string assetPath) where T : UnityEngine.Object
        {
            UnityEngine.Object obj = AssetDatabase.LoadAssetAtPath(assetPath, typeof(T));

            #if DEBUG 
            Debug.Log("Loading asset at: " + assetPath + ". asset: " + obj);
            #endif

            return (T)obj;
        }
    }
}
